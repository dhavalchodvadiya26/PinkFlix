package com.example.videostreamingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.databinding.DataBindingUtil;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.adapter.MenuCategoryAdapter;
import com.example.base.BaseActivity;
import com.example.fragment.HomeFragment;

import com.example.fragment.MoreFragment;
import com.example.fragment.PrimiumCategoryFragment;
import com.example.fragment.SettingFragment;
import com.example.fragment.ShowsTabFragment;
import com.example.fragment.SportCategoryFragment;
import com.example.model.menu.MenuCategory;
import com.example.util.API;
import com.example.util.Constant;
import com.example.util.DialogUtils;
import com.example.util.GradientTextView;
import com.example.util.IsRTL;
import com.example.util.PrettyDialog;
import com.example.util.Remember;
import com.example.util.fullscreen.FullScreenDialogFragment;
import com.example.videostreamingapp.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.ixidev.gdpr.GDPRChecker;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class MainActivity extends BaseActivity implements MenuCategoryAdapter.SetOnExpandClickListener, FullScreenDialogFragment.OnConfirmListener,
        FullScreenDialogFragment.OnDiscardListener,
        FullScreenDialogFragment.OnDiscardFromExtraActionListener,
        DialogUtils.AlertDialogListener {

    NavigationView navigationView;
    Toolbar toolbar;
    boolean doubleBackToExitPressedOnce = false;
    MyApplication myApplication;
    ActivityMainBinding mBinding;
    private DrawerLayout drawerLayout;
    private FragmentManager fragmentManager;
    private BottomNavigationView bottomNavigationView;
    private FullScreenDialogFragment dialogFragment;
    private GradientTextView toolbarText;
    private boolean isTimerFinished = true;
    private boolean isStopped = false;
    private View.OnClickListener mMenuClickListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.ll_home:
                    HomeFragment homeFragment = new HomeFragment();
                    loadFrag(homeFragment, getString(R.string.menu_home), fragmentManager);
                    break;
                case R.id.ll_watchlist:
                    Intent intentProfile = new Intent(MainActivity.this, WatchListActivity.class);
                    intentProfile.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intentProfile);
                    break;
                case R.id.ll_transaction:
                    Intent intenttransaction = new Intent(MainActivity.this, TransactionListActivity.class);
                    intenttransaction.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intenttransaction);
                    break;
                case R.id.ll_setting:
                    SettingFragment settingFragment = new SettingFragment();
                    loadFrag(settingFragment, getString(R.string.menu_setting), fragmentManager);
                    break;
                case R.id.ll_logout:
                    logOut();
                    break;
                case R.id.ll_login:
                    Intent intentSignIn = new Intent(MainActivity.this, SignInActivity.class);
                    intentSignIn.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intentSignIn);
                    finish();
                    break;
                case R.id.ll_dashboard:
                    Intent intentDashBoard = new Intent(MainActivity.this, DashboardActivity.class);
                    intentDashBoard.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intentDashBoard);
                    break;
            }
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START);
            }
        }


    };

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        IsRTL.ifSupported(this);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbarText = toolbar.findViewById(R.id.toolbarText);
        navigationView = findViewById(R.id.navigation_view);
        drawerLayout = findViewById(R.id.drawer_layout);
        fragmentManager = getSupportFragmentManager();
        myApplication = MyApplication.getInstance();
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setItemIconTintList(null);
        bottomNavigationView.setItemTextColor(null);
        bottomNavigationView.setOnNavigationItemSelectedListener(
                item -> {
                    int itemId = item.getItemId();
                    if (!isStopped && isTimerFinished) {
                        if (itemId == R.id.navigation_home) {
                            HomeFragment homeFragment = new HomeFragment();
                            loadFrag(homeFragment, getString(R.string.menu_home), fragmentManager);
                            isTimerFinished = false;
                            new Handler().postDelayed(() -> isTimerFinished = true, 2000);
                        } else if (itemId == R.id.navigation_movies) {
                            openMenu("movie", 1);
                            isTimerFinished = false;
                            new Handler().postDelayed(() -> isTimerFinished = true, 2000);
                        } else if (itemId == R.id.navigation_premium) {
                            openMenu("premium", 0);
                            isTimerFinished = false;
                            new Handler().postDelayed(() -> isTimerFinished = true, 2000);
                        } else if (itemId == R.id.navigation_series) {
                            openMenu("web series", 1);
                            isTimerFinished = false;
                            new Handler().postDelayed(() -> isTimerFinished = true, 2000);
                        } else if (itemId == R.id.navigation_more) {
                            openDialog();
                            isTimerFinished = false;
                            new Handler().postDelayed(() -> isTimerFinished = true, 2000);
                        }
                        return true;
                    } else {
                        return false;
                    }

                });

        new GDPRChecker()
                .withContext(MainActivity.this)
                .withPrivacyUrl(getString(R.string.privacy_url)) // your privacy url
                .withPublisherIds(Constant.adMobPublisherId) // your admob account Publisher id
                .withTestMode("9424DF76F06983D1392E609FC074596C") // remove this on real project
                .check();

        LinearLayout mAdViewLayout = findViewById(R.id.adView);
        /*BannerAds.showBannerAds(this, mAdViewLayout);*/

        HomeFragment homeFragment = new HomeFragment();
        loadFrag(homeFragment, getString(R.string.menu_home), fragmentManager);

        mBinding.partialMenu.llHome.setOnClickListener(mMenuClickListener);
        mBinding.partialMenu.llDashboard.setOnClickListener(mMenuClickListener);
        mBinding.partialMenu.llLogin.setOnClickListener(mMenuClickListener);
        mBinding.partialMenu.llLogout.setOnClickListener(mMenuClickListener);
        mBinding.partialMenu.llWatchlist.setOnClickListener(mMenuClickListener);
        mBinding.partialMenu.llSetting.setOnClickListener(mMenuClickListener);
        mBinding.partialMenu.llTransaction.setOnClickListener(mMenuClickListener);
        mBinding.partialMenu.expMenu.setOnChildClickListener((parent, v, groupPosition, childPosition, id) -> navigateToNext(parent, groupPosition, childPosition));
        mBinding.partialMenu.expMenu.setOnGroupClickListener((parent, v, groupPosition, id) -> {
            if (((MenuCategoryAdapter) parent.getExpandableListAdapter()).getGroup(groupPosition).getSubcategory() == null && ((MenuCategoryAdapter) parent.getAdapter()).getGroup(groupPosition).getSubcategory().size() <= 0) {
                drawerLayout.closeDrawer(GravityCompat.START);
                return navigateToNext(parent, groupPosition, 0);
            }
            return false;
        });
        getCategory();

//        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
//                drawerLayout.closeDrawers();
//                switch (menuItem.getItemId()) {
//                    case R.id.menu_go_home:
//                        HomeFragment homeFragment = new HomeFragment();
//                        loadFrag(homeFragment, getString(R.string.menu_home), fragmentManager);
//                        return true;
//                    case R.id.menu_go_movie:
//                        ShowsTabFragment movieTabFragment = new ShowsTabFragment();
//                        Bundle bundleMovie = new Bundle();
//                        bundleMovie.putBoolean("isShow", false);
//                        movieTabFragment.setArguments(bundleMovie);
//                        loadFrag(movieTabFragment, getString(R.string.menu_movie), fragmentManager);
//                        return true;
//                    case R.id.menu_go_tv_show:
//                        ShowsTabFragment showsTabFragment = new ShowsTabFragment();
//                        Bundle bundleShow = new Bundle();
//                        bundleShow.putBoolean("isShow", true);
//                        showsTabFragment.setArguments(bundleShow);
//                        loadFrag(showsTabFragment, getString(R.string.menu_tv_show), fragmentManager);
//                        return true;
//                    case R.id.menu_go_sport:
//                        SportCategoryFragment sportCategoryFragment = new SportCategoryFragment();
//                        loadFrag(sportCategoryFragment, getString(R.string.menu_sport), fragmentManager);
//                        return true;
//                    case R.id.menu_go_tv:
//                        TVCategoryFragment tvCategoryFragment = new TVCategoryFragment();
//                        loadFrag(tvCategoryFragment, getString(R.string.menu_tv), fragmentManager);
//                        return true;
//                    case R.id.menu_go_profile:
//                        Intent intentProfile = new Intent(MainActivity.this, EditProfileActivity.class);
//                        intentProfile.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                        startActivity(intentProfile);
//                        return true;
//                    case R.id.menu_go_setting:
//                        SettingFragment settingFragment = new SettingFragment();
//                        loadFrag(settingFragment, getString(R.string.menu_setting), fragmentManager);
//                        return true;
//                    case R.id.menu_go_logout:
//                        logOut();
//                        return true;
//                    case R.id.menu_go_login:
//                        Intent intentSignIn = new Intent(MainActivity.this, SignInActivity.class);
//                        intentSignIn.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                        startActivity(intentSignIn);
//                        finish();
//                        return true;
//                    case R.id.menu_go_dashboard:
//                        Intent intentDashBoard = new Intent(MainActivity.this, DashboardActivity.class);
//                        intentDashBoard.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                        startActivity(intentDashBoard);
//                        return true;
//                    default:
//                        return true;
//                }
//            }
//        });

        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }
        };

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
//        actionBarDrawerToggle.syncState();
//        toolbar.setNavigationIcon(R.drawable.ic_side_nav);
        ImageView mTitle = toolbar.findViewById(R.id.ic_subscribe);

        mTitle.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, PlanActivity.class));
        });

        final String dialogTag = "dialog";
        if (savedInstanceState != null) {
            dialogFragment =
                    (FullScreenDialogFragment) getSupportFragmentManager().findFragmentByTag(dialogTag);
            if (dialogFragment != null) {
                dialogFragment.setOnConfirmListener(this);
                dialogFragment.setOnDiscardListener(this);
                dialogFragment.setOnDiscardFromExtraActionListener(this);
            }
        }
    }

    private void openDialog() {
        final Bundle args = new Bundle();
        args.putString("name", "Mehul");


        dialogFragment = new FullScreenDialogFragment.Builder(MainActivity.this)
                .setTitle(R.string.app_name)
                .setConfirmButton(R.string.view_all)
                .setOnConfirmListener(MainActivity.this)
                .setOnDiscardListener(MainActivity.this)
                .setContent(MoreFragment.class, args)
                .setExtraActions(R.menu.navigation)
                .setOnDiscardFromActionListener(MainActivity.this)
                .build();

        dialogFragment.show(getSupportFragmentManager(), "dialog");
    }


    private boolean navigateToNext(ExpandableListView parent, int groupPosition, int childposition) {

        if (((MenuCategoryAdapter) parent.getExpandableListAdapter()).getGroup(groupPosition).getCategoryName().toLowerCase().contains("movie")) {
            ShowsTabFragment movieTabFragment = new ShowsTabFragment();
            Bundle bundleMovie = new Bundle();
            bundleMovie.putBoolean("isShow", false);
            bundleMovie.putString("position", String.valueOf(childposition));
            movieTabFragment.setArguments(bundleMovie);
            loadFrag(movieTabFragment, getString(R.string.menu_movie), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        } else if (((MenuCategoryAdapter) parent.getExpandableListAdapter()).getGroup(groupPosition).getCategoryName().toLowerCase().contains("tv")) {
            ShowsTabFragment movieTabFragment = new ShowsTabFragment();
            Bundle bundleMovie = new Bundle();
            bundleMovie.putBoolean("isShow", false);
            bundleMovie.putString("position", String.valueOf(childposition));
            movieTabFragment.setArguments(bundleMovie);
            loadFrag(movieTabFragment, getString(R.string.menu_tv_show), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        } else if (((MenuCategoryAdapter) parent.getExpandableListAdapter()).getGroup(groupPosition).getCategoryName().toLowerCase().contains("sports")) {
            SportCategoryFragment sportCategoryFragment = new SportCategoryFragment();
            loadFrag(sportCategoryFragment, getString(R.string.menu_sport), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            Remember.putString(Constant.POSITION, String.valueOf(childposition));
            return true;
        } else if (((MenuCategoryAdapter) parent.getExpandableListAdapter()).getGroup(groupPosition).getCategoryName().toLowerCase().contains("premium")) {
            PrimiumCategoryFragment primiumCategoryFragment = new PrimiumCategoryFragment();
            loadFrag(primiumCategoryFragment, getString(R.string.menu_Premium), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            Remember.putString(Constant.POSITION, String.valueOf(childposition));
            return true;
        } else if (((MenuCategoryAdapter) parent.getExpandableListAdapter()).getGroup(groupPosition).getCategoryName().toLowerCase().equalsIgnoreCase("web series")) {
            ShowsTabFragment movieTabFragment = new ShowsTabFragment();
            Bundle bundleMovie = new Bundle();
            bundleMovie.putBoolean("isShow", true);
            bundleMovie.putString("position", String.valueOf(childposition));
            movieTabFragment.setArguments(bundleMovie);
            loadFrag(movieTabFragment, getString(R.string.menu_movie), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        }
        return false;
    }

    public void loadFrag(Fragment f1, String name, FragmentManager fm) {
        for (int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.Container, f1, name);
        ft.commit();
        setToolbarTitle(name);
    }

    public void setToolbarTitle(String Title) {
        if (getSupportActionBar() != null) {
//            getSupportActionBar().setTitle(Title);
            toolbarText.setText(Title);
//            toolbar.setTitleTextColor(getResources().getColor(R.color.colorAccent));
        }
    }


    public void setHeader() {
        if (myApplication.getIsLogin() && navigationView != null) {
//            View header = navigationView.getHeaderView(0);
//            TextView txtHeaderName = header.findViewById(R.id.nav_name);
//            TextView txtHeaderEmail = header.findViewById(R.id.nav_email);
//            txtHeaderName.setText(myApplication.getUserName());
//            txtHeaderEmail.setText(myApplication.getUserEmail());

            mBinding.navHeader.setEmail(myApplication.getUserEmail());
            mBinding.navHeader.setName(myApplication.getUserName());
        }

        mBinding.partialMenu.setIsLogin(myApplication.getIsLogin());

//        if (myApplication.getIsLogin()) {
//            navigationView.getMenu().findItem(R.id.menu_go_login).setVisible(false);
//            navigationView.getMenu().findItem(R.id.menu_go_profile).setVisible(true);
//            navigationView.getMenu().findItem(R.id.menu_go_logout).setVisible(true);
//            navigationView.getMenu().findItem(R.id.menu_go_dashboard).setVisible(true);
//        } else {
//            navigationView.getMenu().findItem(R.id.menu_go_login).setVisible(true);
//            navigationView.getMenu().findItem(R.id.menu_go_profile).setVisible(false);
//            navigationView.getMenu().findItem(R.id.menu_go_logout).setVisible(false);
//            navigationView.getMenu().findItem(R.id.menu_go_dashboard).setVisible(false);
//        }
    }

    private void logOut() {
        PrettyDialog pDialog = new PrettyDialog(this);
        pDialog
                .setTitle(getString(R.string.menu_logout))
                .setMessage(getString(R.string.logout_msg))
                .setIcon(R.drawable.logout)
                .addButton(
                        getString(R.string.menu_logout),
                        R.color.pdlg_color_white,
                        R.color.pdlg_color_green,
                        () -> {
                            pDialog.dismiss();
                            myApplication.saveIsLogin(false);
                            Intent intent = new Intent(getApplicationContext(), SignInActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            Remember.clear();
                            finish();
                        }).addButton(
                getString(android.R.string.no),
                R.color.pdlg_color_white,
                R.color.pdlg_color_red,
                pDialog::dismiss)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setHeader();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);
        final MenuItem searchMenuItem = menu.findItem(R.id.search);

        final SearchView searchView = (SearchView) searchMenuItem.getActionView();

        searchView.setOnQueryTextFocusChangeListener((v, hasFocus) -> {
            // TODO Auto-generated method stub
            if (!hasFocus) {
                searchMenuItem.collapseActionView();
                searchView.setQuery("", false);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String arg0) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(MainActivity.this, SearchHorizontalActivity.class);
                intent.putExtra("search", arg0);
                startActivity(intent);
                searchView.clearFocus();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String arg0) {
                // TODO Auto-generated method stub
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else if (fragmentManager.getBackStackEntryCount() != 0) {
            String tag = fragmentManager.getFragments().get(fragmentManager.getBackStackEntryCount() - 1).getTag();
            setToolbarTitle(tag);
            super.onBackPressed();
        } else {
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, getString(R.string.back_key), Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Fragment fragment = fragmentManager.findFragmentByTag(getString(R.string.menu_profile));
        if (fragment != null) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void getCategory() {
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        params.put("data", API.toBase64(jsObj.toString()));
        client.post(Constant.MENU_CATEGORY_URL, params, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                showProgressDialog();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                dismissProgressDialog();

                String result = new String(responseBody);
                try {
                    MenuCategory mMenuCategory = gson.fromJson(result, MenuCategory.class);
                    if (mMenuCategory.getStatusCode() == 200) {
                        MenuCategoryAdapter mMenuCategoryAdapter = new MenuCategoryAdapter(mMenuCategory.getVideoStreamApp(), MainActivity.this, MainActivity.this);
                        mBinding.partialMenu.expMenu.setAdapter(mMenuCategoryAdapter);
                    } else {
                        mBinding.partialMenu.expMenu.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    mBinding.partialMenu.expMenu.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                dismissProgressDialog();
            }

        });
    }

    @Override
    public void onExpand(int groupPos, ImageButton ibExp) {
        if (mBinding.partialMenu.expMenu.isGroupExpanded(groupPos)) {
            mBinding.partialMenu.expMenu.collapseGroup(groupPos);
            ibExp.setRotation(0);
        } else {
            mBinding.partialMenu.expMenu.expandGroup(groupPos, true);
            ibExp.setRotation(180);
        }
    }

    public void profile(View v) {
        startActivity(new Intent(MainActivity.this, EditProfileActivity.class));
    }

    @Override
    public void onConfirm(@Nullable Bundle result) {
        String value;
        if (result != null) {
            value = result.getString("RESULT_FULL_NAME");
            assert value != null;
            if (value.equalsIgnoreCase("WatchList")) {
                if (myApplication.getIsLogin()) {
                    Intent intentProfile = new Intent(MainActivity.this, WatchListActivity.class);
                    intentProfile.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intentProfile);
                } else {
                    showAlert();
                }

            } else if (value.equalsIgnoreCase("MyTransaction")) {
                if (myApplication.getIsLogin()) {
                    Intent intenttransaction = new Intent(MainActivity.this, TransactionListActivity.class);
                    intenttransaction.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intenttransaction);
                } else
                    showAlert();
            } else if (value.equalsIgnoreCase("Logout")) {
                logOut();
            } else if (value.equalsIgnoreCase("Login")) {
                showAlert();
            } else if (value.equalsIgnoreCase("MyAccount")) {
                if (myApplication.getIsLogin()) {
                    Intent intenttransaction = new Intent(MainActivity.this, DashboardActivity.class);
                    intenttransaction.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intenttransaction);
                } else
                    showAlert();
            } else if (value.equalsIgnoreCase("Membership")) {
                if (myApplication.getIsLogin()) {
                    startActivity(new Intent(MainActivity.this, PlanActivity.class));
                } else
                    showAlert();
            } else if (value.equalsIgnoreCase("Setting")) {
                if (myApplication.getIsLogin()) {
                    SettingFragment settingFragment = new SettingFragment();
                    loadFrag(settingFragment, getString(R.string.menu_setting), fragmentManager);
                } else
                    showAlert();
            } else if (value.equalsIgnoreCase("LiveTv")) {
                Intent intent = new Intent(MainActivity.this, MovieDetailsActivity.class);
                intent.putExtra("Id", "179");
                intent.putExtra("live", true);
                startActivity(intent);
            }
        }

    }

    private void showAlert() {
        PrettyDialog pDialog = new PrettyDialog(this);
        pDialog
                .setTitle(getString(R.string.menu_login))
                .setMessage("Please Login to Enjoy Endless Streaming !!")
                .setIcon(R.drawable.login)
                .addButton(
                        getString(R.string.menu_login),
                        R.color.pdlg_color_white,
                        R.color.pdlg_color_green,
                        () -> {
                            pDialog.dismiss();
                            login();
                        }).addButton(
                getString(android.R.string.no),
                R.color.pdlg_color_white,
                R.color.pdlg_color_red,
                pDialog::dismiss)
                .show();
    }

    private void login() {
        startActivity(new Intent(MainActivity.this, SignInActivity.class));
    }

    @Override
    public void onDiscard() {
        bottomNavigationView.setSelectedItemId(R.id.navigation_home);
    }

    @Override
    public void onDiscardFromExtraAction(int actionId, @Nullable Bundle result) {
        bottomNavigationView.setSelectedItemId(R.id.navigation_home);
    }

    private boolean openMenu(String parent, int childposition) {

        if (parent.toLowerCase().contains("movie")) {
            ShowsTabFragment movieTabFragment = new ShowsTabFragment();
            Bundle bundleMovie = new Bundle();
            bundleMovie.putBoolean("isShow", false);
            bundleMovie.putString("position", String.valueOf(childposition));
            movieTabFragment.setArguments(bundleMovie);
            loadFrag(movieTabFragment, getString(R.string.menu_movie), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        } else if (parent.toLowerCase().contains("tv")) {
            ShowsTabFragment movieTabFragment = new ShowsTabFragment();
            Bundle bundleMovie = new Bundle();
            bundleMovie.putBoolean("isShow", false);
            bundleMovie.putString("position", String.valueOf(childposition));
            movieTabFragment.setArguments(bundleMovie);
            loadFrag(movieTabFragment, getString(R.string.menu_tv_show), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        } else if (parent.toLowerCase().contains("sports")) {
            SportCategoryFragment sportCategoryFragment = new SportCategoryFragment();
            loadFrag(sportCategoryFragment, getString(R.string.menu_sport), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            Remember.putString(Constant.POSITION, String.valueOf(childposition));
            return true;
        } else if (parent.toLowerCase().contains("premium")) {
            PrimiumCategoryFragment primiumCategoryFragment = new PrimiumCategoryFragment();
            loadFrag(primiumCategoryFragment, getString(R.string.menu_Premium), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            Remember.putString(Constant.POSITION, String.valueOf(childposition));
            return true;
        } else if (parent.toLowerCase().equalsIgnoreCase("web series")) {
            ShowsTabFragment movieTabFragment = new ShowsTabFragment();
            Bundle bundleMovie = new Bundle();
            bundleMovie.putBoolean("isShow", true);
            bundleMovie.putString("position", "0");
            movieTabFragment.setArguments(bundleMovie);
            loadFrag(movieTabFragment, getString(R.string.menu_web_series), fragmentManager);
            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        }
        return false;
    }

    @Override
    protected void onStop() {
        isStopped = true;
        super.onStop();
    }

    @Override
    protected void onStart() {
        super.onStart();
        isStopped = false;

    }

    @Override
    public void onPositiveClick(int from) {
        if (from == 101)
            login();
    }

    @Override
    public void onNegativeClick(int from) {

    }

    @Override
    public void onNeutralClick(int from) {

    }
}
