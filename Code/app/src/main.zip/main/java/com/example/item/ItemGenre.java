package com.example.item;

public class ItemGenre {

    private String genreId;
    private String genreName;
    private String genreImage;

    public String getGenreId() {
        return genreId;
    }

    public void setGenreId(String genreId) {
        this.genreId = genreId;
    }

    public String getGenreName() {
        return genreName;
    }

    public void setGenreName(String genreName) {
        this.genreName = genreName;
    }

    public String getGenreImage() {
        return genreImage;
    }

    public void setGenreImage(String genreImage) {
        this.genreImage = genreImage;
    }
}
