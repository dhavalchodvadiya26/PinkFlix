package com.example.item;

public class ItemRecent {
    private String recentId;
    private String recentType;
    private String recentImage;

    public String getRecentId() {
        return recentId;
    }

    public void setRecentId(String recentId) {
        this.recentId = recentId;
    }

    public String getRecentType() {
        return recentType;
    }

    public void setRecentType(String recentType) {
        this.recentType = recentType;
    }

    public String getRecentImage() {
        return recentImage;
    }

    public void setRecentImage(String recentImage) {
        this.recentImage = recentImage;
    }
}
