package com.example.util;

public interface FilterDialogListener {
    void confirm(String filterTag, int filterPosition);
}
