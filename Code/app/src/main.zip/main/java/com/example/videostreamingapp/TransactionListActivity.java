package com.example.videostreamingapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adapter.RentalAdapter;
import com.example.adapter.TransactionAdapter;
import com.example.item.ItemMovie;
import com.example.item.ItemSubscription;
import com.example.item.ItemTransaction;
import com.example.util.API;
import com.example.util.Constant;
import com.example.util.IsRTL;
import com.example.util.NetworkUtils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class TransactionListActivity extends AppCompatActivity {
    private RecyclerView rvRecently;
    private RecyclerView rv_rental;
    private RecyclerView rv_donation;
    private MyApplication myApplication;
    private ArrayList<ItemTransaction> recentList;
    private ArrayList<ItemSubscription> recentTransactionList;
    private TransactionAdapter latestMovieAdapter;
    private RentalAdapter rentalAdapter;
    private TextView txtDonation;
    private TextView txtRental;
    private TextView txtSubscription;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_list);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        IsRTL.ifSupported(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Transaction");
        }
        myApplication = MyApplication.getInstance();
        txtSubscription = findViewById(R.id.txtSubscription);
        txtRental = findViewById(R.id.txtRental);
        txtDonation = findViewById(R.id.txtDonation);
        rvRecently = findViewById(R.id.rv_recently_watched);
        rv_rental = findViewById(R.id.rv_rental);
        rv_donation = findViewById(R.id.rv_donation);
        recyclerViewProperty(rvRecently);
        recyclerViewProperty(rv_rental);
        recyclerViewProperty(rv_donation);
        recentList = new ArrayList<>();
        recentTransactionList = new ArrayList<>();
        if (NetworkUtils.isConnected(TransactionListActivity.this)) {
            getToWatchList();
        } else {
            showToast(getString(R.string.conne_msg1));
        }

    }

    public void showToast(String msg) {
        Toast.makeText(TransactionListActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void recyclerViewProperty(RecyclerView recyclerView) {
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(TransactionListActivity.this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setFocusable(false);
        recyclerView.setNestedScrollingEnabled(false);
    }

    private void getToWatchList() {
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        jsObj.addProperty("user_id", myApplication.getIsLogin() ? myApplication.getUserId() : "");
        params.put("data", API.toBase64(jsObj.toString()));

        client.post(Constant.GET_TRANSACTION_LIST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();


            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String result = new String(responseBody);
                try {
                    JSONObject mainJson = new JSONObject(result);
                    if (mainJson.optString("status_code").equalsIgnoreCase("200")) {
                        JSONObject video_Json = mainJson.optJSONObject("VIDEO_STREAMING_APP");

                        assert video_Json != null;
                        JSONArray subscription_array = video_Json.optJSONArray("subscription_plan");
                        JSONArray rental_array = video_Json.optJSONArray("rental_plan");
                        JSONArray donation_array = video_Json.optJSONArray("donate_plan");

                        assert subscription_array != null;
                        for (int i = 0; i < subscription_array.length(); i++) {
                            JSONObject jsonObject = subscription_array.getJSONObject(i);
                            ItemSubscription itemSubscription = new ItemSubscription();
                            itemSubscription.setTransactionId(jsonObject.getString("transction_plan_name"));
                            itemSubscription.setTransction_user_id(jsonObject.getString("transction_user_id"));
                            itemSubscription.setTransction_email(jsonObject.getString("transction_email"));
                            itemSubscription.setTransction_plan_id(jsonObject.getString("transction_plan_id"));
                            itemSubscription.setTransction_gateway(jsonObject.getString("transction_gateway"));
                            itemSubscription.setTransction_payment_amount(jsonObject.getString("transction_payment_amount"));
                            itemSubscription.setTransction_payment_id(jsonObject.getString("transction_payment_id"));
                            itemSubscription.setTransction_promocode(jsonObject.getString("transction_promocode"));
                            itemSubscription.setTransction_donate_flag(jsonObject.getString("transction_donate_flag"));
                            itemSubscription.setTransction_date(jsonObject.getString("transction_date"));
                            itemSubscription.setTransction_expiry_date(jsonObject.getString("transction_expiry_date"));

                            recentTransactionList.add(itemSubscription);
                            latestMovieAdapter = new TransactionAdapter(recentTransactionList);
                            rvRecently.setAdapter(latestMovieAdapter);
                        }
                        if (subscription_array.length() > 0)
                            txtSubscription.setVisibility(View.VISIBLE);
                        recentList.clear();
                        assert rental_array != null;
                        for (int i = 0; i < rental_array.length(); i++) {
                            JSONObject jsonObject = rental_array.getJSONObject(i);
                            ItemTransaction itemTransaction = new ItemTransaction();
                            itemTransaction.setTransactionId(jsonObject.getString("transction_plan_name"));
                            itemTransaction.setTransction_user_id(jsonObject.getString("transction_user_id"));
                            itemTransaction.setTransction_email(jsonObject.getString("transction_email"));
                            itemTransaction.setTransction_plan_id(jsonObject.getString("transction_plan_id"));
                            itemTransaction.setTransction_gateway(jsonObject.getString("transction_gateway"));
                            itemTransaction.setTransction_payment_amount(jsonObject.getString("transction_payment_amount"));
                            itemTransaction.setTransction_payment_id(jsonObject.getString("transction_payment_id"));
                            itemTransaction.setTransction_promocode(jsonObject.getString("transction_promocode"));
                            itemTransaction.setTransction_donate_flag(jsonObject.getString("transction_donate_flag"));
                            itemTransaction.setTransction_date(jsonObject.getString("transction_date"));
                            itemTransaction.setMovie_name(jsonObject.getString("movie_name"));
                            itemTransaction.setExpirty_date(jsonObject.getString("expirty_date"));

                            recentList.add(itemTransaction);

                        }

                        if (rental_array.length() > 0) {
                            txtRental.setVisibility(View.VISIBLE);
                            rentalAdapter = new RentalAdapter(recentList);
                            rv_rental.setAdapter(rentalAdapter);
                        }
                        assert donation_array != null;
                        for (int i = 0; i < donation_array.length(); i++) {
                            JSONObject jsonObject = donation_array.getJSONObject(i);
                            ItemTransaction itemTransaction = new ItemTransaction();
                            itemTransaction.setTransactionId(jsonObject.getString("transction_plan_name"));
                            itemTransaction.setTransction_user_id(jsonObject.getString("transction_user_id"));
                            itemTransaction.setTransction_email(jsonObject.getString("transction_email"));
                            itemTransaction.setTransction_plan_id(jsonObject.getString("transction_plan_id"));
                            itemTransaction.setTransction_gateway(jsonObject.getString("transction_gateway"));
                            itemTransaction.setTransction_payment_amount(jsonObject.getString("transction_payment_amount"));
                            itemTransaction.setTransction_payment_id(jsonObject.getString("transction_payment_id"));
                            itemTransaction.setTransction_promocode(jsonObject.getString("transction_promocode"));
                            itemTransaction.setTransction_donate_flag(jsonObject.getString("transction_donate_flag"));

                            recentList.clear();
                            recentList.add(itemTransaction);
//                            latestMovieAdapter = new TransactionAdapter(recentList);
                            rv_donation.setAdapter(latestMovieAdapter);
                        }

                        if (donation_array.length() > 0)
                            txtDonation.setVisibility(View.VISIBLE);

                    } else {

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.e("Transaction", error.getMessage());
            }
        });
    }

}
