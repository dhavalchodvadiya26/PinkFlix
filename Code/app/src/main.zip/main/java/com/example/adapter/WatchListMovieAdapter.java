package com.example.adapter;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.item.ItemMovie;
import com.example.util.DialogUtil;
import com.example.util.GradientTextView;
import com.example.util.NetworkUtils;
import com.example.util.PopUpAds;
import com.example.util.RvOnClickListener;
import com.example.videostreamingapp.MovieDetailsActivity;
import com.example.videostreamingapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class WatchListMovieAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<ItemMovie> dataList;
    private Context mContext;
    private RvOnClickListener clickListener;
    private int columnWidth;
    private boolean isRTL;
    private boolean isHomeMore;

    public WatchListMovieAdapter(Context context, ArrayList<ItemMovie> dataList, boolean isHomeMore) {
        this.dataList = dataList;
        this.mContext = context;
        columnWidth = NetworkUtils.getScreenWidth(mContext);
        isRTL = Boolean.parseBoolean(mContext.getString(R.string.isRTL));
        this.isHomeMore = isHomeMore;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_row_watch_list_item, parent, false);
        return new ItemRowHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder viewHolder, final int position) {
        final ItemRowHolder holder = (ItemRowHolder) viewHolder;
        final ItemMovie singleItem = dataList.get(position);

        holder.image.setLayoutParams(new RelativeLayout.LayoutParams(columnWidth / 4 - 20, columnWidth / 4 + 60));
//        holder.txtGenre.setText(singleItem.getMovieType());
//        holder.txtLanguage.setText(singleItem.getMovieLanguage());
        holder.txtDuration.setText(singleItem.getMovieDuration());
        holder.txtMovieName.setText(singleItem.getMovieName());

        Picasso.with(mContext).load(singleItem.getMovieImage()).into(holder.image);
        holder.cardView.setOnClickListener(v -> PopUpAds.showInterstitialAds(mContext, holder.getAdapterPosition(), clickListener));


    }

    @Override
    public int getItemCount() {
        return (null != dataList ? dataList.size() : 0);
    }


    public void setOnItemClickListener(RvOnClickListener clickListener) {
        this.clickListener = clickListener;
    }

    class ItemRowHolder extends RecyclerView.ViewHolder {
        ImageView image,imgDownload;
        TextView txtGenre, txtLanguage, txtDuration,txtMovieName;
        GradientTextView txtDownload;
        CardView cardView;
        RelativeLayout rootLayout;

        ItemRowHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.image);
            imgDownload=itemView.findViewById(R.id.imgDownload);

            txtGenre = itemView.findViewById(R.id.txtGenre);
            txtLanguage = itemView.findViewById(R.id.txtLanguage);
            txtDuration = itemView.findViewById(R.id.txtDuration);
            cardView = itemView.findViewById(R.id.cardView);
            rootLayout = itemView.findViewById(R.id.rootLayout);
            txtMovieName = itemView.findViewById(R.id.txtMovieName);
            txtDownload=itemView.findViewById(R.id.txtDownload);



            txtDownload.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DialogUtil.AlertBox(view.getContext(), "Moviesy", "This Feature will be available in live application");
                }
            });

            imgDownload.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DialogUtil.AlertBox(view.getContext(), "Moviesy", "This Feature will be available in live application");
                }
            });
        }
    }
}
