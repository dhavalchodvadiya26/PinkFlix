package com.example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class WatchListModel {
    @SerializedName("VIDEO_STREAMING_APP")
    @Expose
    private List<VIDEOSTREAMINGAPP> vIDEOSTREAMINGAPP = null;
    @SerializedName("status_code")
    @Expose
    private Integer statusCode;

    public List<VIDEOSTREAMINGAPP> getVIDEOSTREAMINGAPP() {
        return vIDEOSTREAMINGAPP;
    }

    public void setVIDEOSTREAMINGAPP(List<VIDEOSTREAMINGAPP> vIDEOSTREAMINGAPP) {
        this.vIDEOSTREAMINGAPP = vIDEOSTREAMINGAPP;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }
    public class VIDEOSTREAMINGAPP {

        @SerializedName("msg")
        @Expose
        private String msg;
        @SerializedName("success")
        @Expose
        private String success;
        @SerializedName("data")
        @Expose
        private List<Datum> data = null;

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public String getSuccess() {
            return success;
        }

        public void setSuccess(String success) {
            this.success = success;
        }

        public List<Datum> getData() {
            return data;
        }

        public void setData(List<Datum> data) {
            this.data = data;
        }

    }
    public class Datum {

        @SerializedName("id")
        @Expose
        private Integer id;
        @SerializedName("user_id")
        @Expose
        private String userId;
        @SerializedName("movie_videos_id")
        @Expose
        private String movieVideosId;
        @SerializedName("created_at")
        @Expose
        private String createdAt;
        @SerializedName("updated_at")
        @Expose
        private String updatedAt;

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getMovieVideosId() {
            return movieVideosId;
        }

        public void setMovieVideosId(String movieVideosId) {
            this.movieVideosId = movieVideosId;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public String getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
        }

    }
}
