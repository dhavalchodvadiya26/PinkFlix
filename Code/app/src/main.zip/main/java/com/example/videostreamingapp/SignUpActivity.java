package com.example.videostreamingapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.dialog.DatePickerDialogFragment;
import com.example.util.API;
import com.example.util.Constant;
import com.example.util.IsRTL;
import com.example.util.NetworkUtils;
import com.facebook.CallbackManager;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.ConfirmPassword;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Password;
import com.ybs.countrypicker.CountryPicker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;


public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {
    @NotEmpty
    EditText edtFullName;
    @Email
    EditText edtEmail;
    @Password
    EditText edtPassword;
    @ConfirmPassword
    EditText edtPasswordConfirm;
    @NotEmpty
    EditText edtDob;
    Button btnSignUp;
    String strName, strEmail, strPassword, strMessage;
    TextView txtLogin;
    ProgressDialog pDialog;
    private ImageView btnFacebookRegister;
    DatePickerDialogFragment datePickerDialogFragment;
    //    private Validator validator;
    private String selectedBirthDay;
    private EditText edtCountry;
    private String mVerificationId;
    private String code = "";

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        IsRTL.ifSupported(this);
        pDialog = new ProgressDialog(this);
        edtFullName = findViewById(R.id.editText_name_register);
        edtDob = findViewById(R.id.editText_dob);
        edtEmail = findViewById(R.id.editText_email_register);
        edtPassword = findViewById(R.id.editText_password_register);
        edtPasswordConfirm = findViewById(R.id.editText_confirm);
        btnFacebookRegister = findViewById(R.id.button_fb_login);
        btnSignUp = findViewById(R.id.button_submit);
        txtLogin = findViewById(R.id.textView_login_register);
        edtCountry = findViewById(R.id.edtCountry);
        edtCountry.setFocusable(false);
        edtCountry.setClickable(true);
        edtCountry.setOnClickListener(this);
        btnSignUp.setOnClickListener(v -> putSignUp());
        btnFacebookRegister.setVisibility(View.GONE);
        //btnFacebookRegister.setOnClickListener(v -> doFacebookSignUp());

        edtDob.setOnClickListener(v -> {
            datePickerDialogFragment = new DatePickerDialogFragment(date -> {
                selectedBirthDay = date;
                edtDob.setText(selectedBirthDay);
                edtDob.setError(null);
            });
            datePickerDialogFragment.show(getSupportFragmentManager(), "DatePickerDialog");
        });

        txtLogin.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), SignInActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });


    }

   /* @Override
    public void onValidationSucceeded() {
        if (NetworkUtils.isConnected(SignUpActivity.this)) {
            putSignUp();
        } else {
            showToast(getString(R.string.conne_msg1));
        }
    }*/

   /* @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(this);
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        }
    }*/

    public void putSignUp() {
        if (!TextUtils.isEmpty(edtFullName.getText().toString().trim()) && !TextUtils.isEmpty(edtEmail.getText().toString().trim())
                && !TextUtils.isEmpty(edtPassword.getText().toString().trim()) && !TextUtils.isEmpty(edtPasswordConfirm.getText().toString().trim())
                && edtPassword.getText().toString().trim().equalsIgnoreCase(edtPasswordConfirm.getText().toString().trim())
        ) {
            strName = edtFullName.getText().toString();
            strEmail = edtEmail.getText().toString();
            strPassword = edtPassword.getText().toString();


            RequestParams params = new RequestParams();

            JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
            jsObj.addProperty("name", strName);
            jsObj.addProperty("email", strEmail);
            jsObj.addProperty("password", strPassword);
            jsObj.addProperty("code", edtCountry.getText().toString().trim());
            params.put("data", API.toBase64(jsObj.toString()));
            if (!edtCountry.getText().toString().trim().equalsIgnoreCase("+91"))
                callSignUpApi(params);
            else
                startActivity(new Intent(SignUpActivity.this, OTPVerificationActivity.class).putExtra("phone", edtEmail.getText().toString().trim())
                        .putExtra("code", edtCountry.getText().toString().trim()).putExtra("data", API.toBase64(jsObj.toString())));

        } else {
            if (TextUtils.isEmpty(edtFullName.getText().toString().trim()))
                showToast("Enter name");
            else if (TextUtils.isEmpty(edtEmail.getText().toString().trim()))
                showToast("Enter mobile number");
            else if (TextUtils.isEmpty(edtPassword.getText().toString().trim()))
                showToast("Enter password");
            else if (TextUtils.isEmpty(edtPasswordConfirm.getText().toString().trim()))
                showToast("Enter confirm password");
            else if (!edtPassword.getText().toString().trim().equalsIgnoreCase(edtPasswordConfirm.getText().toString().trim()))
                showToast("Password & Confirm Password does not Match");

        }
    }

    private void callSignUpApi(RequestParams params) {
        AsyncHttpClient client = new AsyncHttpClient();
        client.post(Constant.REGISTER_URL, params, new AsyncHttpResponseHandler() {

            @Override
            public void onStart() {
                super.onStart();
                showProgressDialog();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                dismissProgressDialog();
                String result = new String(responseBody);
                Log.d("RESULT", result);
                try {
                    JSONObject mainJson = new JSONObject(result);
                    JSONArray jsonArray = mainJson.getJSONArray(Constant.ARRAY_NAME);
                    JSONObject objJson;
                    for (int i = 0; i < jsonArray.length(); i++) {
                        objJson = jsonArray.getJSONObject(i);
                        strMessage = objJson.getString(Constant.MSG);
                        Constant.GET_SUCCESS_MSG = objJson.getInt(Constant.SUCCESS);
                        Constant.VERIFYOTP = objJson.optString(Constant.VERIFY);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (Constant.VERIFYOTP.equalsIgnoreCase("false")) {
                    JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
                    jsObj.addProperty("name", strName);
                    jsObj.addProperty("email", strEmail);
                    jsObj.addProperty("password", strPassword);
                    Intent intent = new Intent(getApplicationContext(), OTPVerificationActivity.class).putExtra("phone", strEmail)
                            .putExtra("data", API.toBase64(jsObj.toString()));
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                } else if (Constant.VERIFY.equalsIgnoreCase("")) {
                    JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
                    jsObj.addProperty("name", strName);
                    jsObj.addProperty("email", strEmail);
                    jsObj.addProperty("password", strPassword);
                    Intent intent = new Intent(getApplicationContext(), OTPVerificationActivity.class).putExtra("phone", strEmail)
                            .putExtra("data", API.toBase64(jsObj.toString()));
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(SignUpActivity.this);
                    builder.setMessage(strMessage)
                            .setCancelable(false)
                            .setPositiveButton("OK", (dialog, id) -> {
                                Intent intent = new Intent(getApplicationContext(), SignInActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                finish();
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                error.printStackTrace();
                dismissProgressDialog();
            }

        });
    }

    public void setResult() {

        if (Constant.VERIFY.equalsIgnoreCase("false")) {
            JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
            jsObj.addProperty("name", strName);
            jsObj.addProperty("email", strEmail);
            jsObj.addProperty("password", strPassword);
            Intent intent = new Intent(getApplicationContext(), OTPVerificationActivity.class).putExtra("phone", strEmail)
                    .putExtra("data", API.toBase64(jsObj.toString()));
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        } else {
            showToast(strMessage);
            Intent intent = new Intent(getApplicationContext(), SignInActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
    }

    public void showToast(String msg) {
        Toast.makeText(SignUpActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    public void showProgressDialog() {
        pDialog.setMessage(getString(R.string.loading));
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();
    }

    public void dismissProgressDialog() {
        if (pDialog != null && pDialog.isShowing()) {
            pDialog.dismiss();
        }
    }

    @Override
    public void onClick(View v) {
        if (v == edtCountry) {
            CountryPicker picker = CountryPicker.newInstance("Select Country");
            picker.setListener((name, code, dialCode, i) -> {
                edtCountry.setText(dialCode);
                picker.dismiss();
            });

            picker.show(getSupportFragmentManager(), "COUNTRY_PICKER");
        }
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

            //Getting the code sent by SMS
            code = phoneAuthCredential.getSmsCode();

            //sometime the code is not detected automatically
            //in this case the code will be null
            //so user has to manually enter the code
           /* if (code != null) {
//                Toaster.longToast(code);

                //verifying the code
//                verifyVerificationCode(code);
            }*/
        }


        @Override
        public void onVerificationFailed(FirebaseException e) {
            Toast.makeText(SignUpActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }


        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            mVerificationId = s;
            startActivity(new Intent(SignUpActivity.this, OTPVerificationActivity.class).putExtra("phone", edtEmail.getText().toString().trim())
                    .putExtra("code", code).putExtra("id", mVerificationId));
        }
    };
}
