package com.example.util;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;

import com.example.videostreamingapp.MyApplication;


public class DeviceUtils {

    private static final String USER_IMEI_NUMBER = "user_imei_number";


    public static String getDeviceUid() {
        Context context = MyApplication.getInstance();
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String uniqueDeviceId = "";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (TextUtils.isEmpty(uniqueDeviceId)) {
                // for tablets
                ContentResolver cr = context.getContentResolver();
                uniqueDeviceId = Settings.Secure.getString(cr, Settings.Secure.ANDROID_ID);
            }
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                uniqueDeviceId = telephonyManager.getImei();
            } else
                uniqueDeviceId = telephonyManager.getDeviceId();
        }

        return uniqueDeviceId;
    }

    public static int getDeviceWidth(Activity activity) {
        DisplayMetrics dm = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        return dm.widthPixels;
    }

    public static int getBatteryPercentage(Context context) {

        IntentFilter iFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.registerReceiver(null, iFilter);

        int level = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        int scale = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;

        float batteryPct = level / (float) scale;

        return (int) (batteryPct * 100);
    }
}
