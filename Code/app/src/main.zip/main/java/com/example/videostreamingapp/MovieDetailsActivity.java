package com.example.videostreamingapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.Html;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adapter.HomeMovieAdapter;
import com.example.adapter.MovieCastAdapter;
import com.example.fragment.EmbeddedImageFragment;
import com.example.fragment.ExoPlayerFragment;
import com.example.fragment.ExoTVPlayerFragment;
import com.example.fragment.PremiumContentFragment;
import com.example.item.CastModel;
import com.example.item.ItemMovie;
import com.example.util.API;
import com.example.util.BannerAds;
import com.example.util.Constant;
import com.example.util.DialogUtil;
import com.example.util.DialogUtils;
import com.example.util.Events;
import com.example.util.GlobalBus;
import com.example.util.GradientTextView;
import com.example.util.IsRTL;
import com.example.util.NetworkUtils;
import com.example.util.PrettyDialog;
import com.example.util.ReadMoreTextView;
import com.example.util.Remember;
import com.example.util.RvOnClickListener;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastState;
import com.google.android.gms.cast.framework.CastStateListener;
import com.google.android.gms.cast.framework.IntroductoryOverlay;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.paypal.android.sdk.payments.LoginActivity;
import com.squareup.picasso.Picasso;

import org.greenrobot.eventbus.Subscribe;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

public class MovieDetailsActivity extends AppCompatActivity implements View.OnClickListener, DialogUtils.AlertDialogListener {

    ProgressBar mProgressBar;
    LinearLayout lyt_not_found;
    RelativeLayout lytParent;

    TextView txtDescription;
    GradientTextView textTitle;
    TextView textDate, textLanguage, textGenre, textRelViewAll, textRate;
    private LinearLayout lytRate, layoutTrailer;
    RecyclerView rvRelated;
    ItemMovie itemMovie;
    ArrayList<ItemMovie> mListItemRelated;
    HomeMovieAdapter homeMovieAdapter;
    String Id;
    StringBuilder strGenre = new StringBuilder();
    LinearLayout lytRelated;
    MyApplication myApplication;
    NestedScrollView nestedScrollView;
    Toolbar toolbar;
    FrameLayout frameLayout;
    boolean isFullScreen = false;
    boolean isFromNotification = false;
    LinearLayout mAdViewLayout;
    boolean isPurchased = false;
    String rental_plan = "";
    private Button btnDownload;
    private FragmentManager fragmentManager;
    private int playerHeight;
    private String strSelectedItemUrl;
    private ImageView btnWatchList;
    private ImageView btnWatchListselect;
    private ImageView btnShare;
    private String strMovieURL, strTrailerURL;
    private boolean addedWatchList = false;
    private ImageView imgTrailer;
    private Button btnRental;
    private TextView txtRentalTime, txtExpire;
    private MenuItem mediaRouteMenuItem;
    private CastStateListener mCastStateListener;
    private CastContext mCastContext;
    private IntroductoryOverlay mIntroductoryOverlay;
    private ImageView imgBack;
    private ImageView btnDownloadMovie;
    private GradientTextView txtMovie;
    public boolean isMovie;
    private TextView txtShare;
    private TextView txtDownload;
    private RecyclerView recyclerCast;
    private static CountDownTimer countDownTimer;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_movie_details);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        IsRTL.ifSupported(this);
        GlobalBus.getBus().register(this);
        txtExpire = findViewById(R.id.txtExpire);
        recyclerCast = findViewById(R.id.recyclerCast);
        recyclerCast.setHasFixedSize(true);
        recyclerCast.setLayoutManager(new LinearLayoutManager(MovieDetailsActivity.this, LinearLayoutManager.HORIZONTAL, false));
        recyclerCast.setFocusable(false);
        recyclerCast.setNestedScrollingEnabled(false);

        mAdViewLayout = findViewById(R.id.adView);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        txtMovie = findViewById(R.id.txtMovie);
        ImageView imgRental = findViewById(R.id.imgRental);
        btnRental = findViewById(R.id.btnRental);
        txtRentalTime = findViewById(R.id.txtRentalTime);
        btnRental.setOnClickListener(this);
        layoutTrailer = findViewById(R.id.layoutTrailer);
        btnShare = findViewById(R.id.btnShare);
        btnDownloadMovie = findViewById(R.id.btnDownloadMovie);
        btnDownloadMovie.setOnClickListener(this);
        btnShare.setOnClickListener(this);
        txtDescription = findViewById(R.id.txtDescription);
        myApplication = MyApplication.getInstance();
        fragmentManager = getSupportFragmentManager();
        Intent intent = getIntent();
        Id = intent.getStringExtra("Id");
        Remember.putString(Constant.MOVIE_ID, Id);
        Remember.putString(Constant.SHOW_ID, "");
        if (intent.hasExtra("isNotification")) {
            isFromNotification = true;
        }

        frameLayout = findViewById(R.id.playerSection);
        int columnWidth = NetworkUtils.getScreenWidth(this);
        frameLayout.setLayoutParams(new RelativeLayout.LayoutParams(columnWidth, columnWidth / 2));
        playerHeight = frameLayout.getLayoutParams().height;

        BannerAds.showBannerAds(this, mAdViewLayout);

        mListItemRelated = new ArrayList<>();
        itemMovie = new ItemMovie();
        lytRelated = findViewById(R.id.lytRelated);
        mProgressBar = findViewById(R.id.progressBar1);
        lyt_not_found = findViewById(R.id.lyt_not_found);
        lytParent = findViewById(R.id.lytParent);
        nestedScrollView = findViewById(R.id.nestedScrollView);

        textRelViewAll = findViewById(R.id.textRelViewAll);
        textTitle = findViewById(R.id.textTitle);
        textDate = findViewById(R.id.textDate);
        textLanguage = findViewById(R.id.txtLanguage);
        textGenre = findViewById(R.id.txtGenre);

        rvRelated = findViewById(R.id.rv_related);
        btnDownload = findViewById(R.id.btnDownload);
        textRate = findViewById(R.id.txtIMDbRating);
        lytRate = findViewById(R.id.lytIMDB);
        btnWatchList = findViewById(R.id.btnWatchList);
        btnWatchListselect = findViewById(R.id.btnWatchListselect);
        btnWatchListselect.setOnClickListener(this);
        btnWatchList.setOnClickListener(this);
        rvRelated.setHasFixedSize(true);
        rvRelated.setLayoutManager(new LinearLayoutManager(MovieDetailsActivity.this, LinearLayoutManager.HORIZONTAL, false));
        rvRelated.setFocusable(false);
        rvRelated.setNestedScrollingEnabled(false);
        imgTrailer = findViewById(R.id.imgTrailer);
        imgBack = findViewById(R.id.imgBack);
        LinearLayout layoutMovieControl = findViewById(R.id.layoutMovieControl);
        imgBack.setOnClickListener(v -> onBackPressed());
        if (NetworkUtils.isConnected(MovieDetailsActivity.this)) {
            getDetails();
        } else {
            showToast(getString(R.string.conne_msg1));
        }

        mCastStateListener = newState -> {
            if (newState != CastState.NO_DEVICES_AVAILABLE) {
                showIntroductoryOverlay();
            }
        };

        mCastContext = CastContext.getSharedInstance(this);

        if (getIntent().getBooleanExtra("live", false))
            layoutMovieControl.setVisibility(View.GONE);
        else
            layoutMovieControl.setVisibility(View.VISIBLE);

        TextView txtWatchList = findViewById(R.id.txtWatchList);
        txtWatchList.setOnClickListener(this);
        txtShare = findViewById(R.id.txtShare);
        txtShare.setOnClickListener(this);
        txtDownload = findViewById(R.id.txtDownload);
        txtDownload.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        mCastContext.addCastStateListener(mCastStateListener);
        super.onResume();
    }

    @Override
    protected void onPause() {
        mCastContext.removeCastStateListener(mCastStateListener);
        super.onPause();
    }

    private void showIntroductoryOverlay() {
        if (mIntroductoryOverlay != null) {
            mIntroductoryOverlay.remove();
        }
        if ((mediaRouteMenuItem != null) && mediaRouteMenuItem.isVisible()) {
            new Handler().post(() -> {
                mIntroductoryOverlay = new IntroductoryOverlay.Builder(
                        MovieDetailsActivity.this, mediaRouteMenuItem)
                        .setTitleText(getString(R.string.app_name))
                        .setSingleTime()
                        .setOnOverlayDismissedListener(
                                new IntroductoryOverlay.OnOverlayDismissedListener() {
                                    @Override
                                    public void onOverlayDismissed() {
                                        mIntroductoryOverlay = null;
                                    }
                                })
                        .build();
                mIntroductoryOverlay.show();
            });
        }
    }

    private void getDetails() {
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        jsObj.addProperty("movie_id", Id);
        jsObj.addProperty("user_id", myApplication.getIsLogin() ? myApplication.getUserId() : "");
        params.put("data", API.toBase64(jsObj.toString()));
        client.post(Constant.MOVIE_DETAILS_URL1, params, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                mProgressBar.setVisibility(View.VISIBLE);
                lytParent.setVisibility(View.GONE);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                mProgressBar.setVisibility(View.GONE);
                lytParent.setVisibility(View.VISIBLE);

                String result = new String(responseBody);
                try {
                    JSONObject mainJson = new JSONObject(result);
                    isPurchased = mainJson.getBoolean(Constant.USER_PLAN_STATUS);
                    JSONObject objJson = mainJson.getJSONObject(Constant.ARRAY_NAME);
                    rental_plan = objJson.optString(Constant.RENTAL_PLAN_STATUS);
                    if (objJson.length() > 0) {
                        if (objJson.has(Constant.STATUS)) {
                            lyt_not_found.setVisibility(View.VISIBLE);
                        } else {
                            itemMovie.setMovieId(objJson.getString(Constant.MOVIE_ID));
                            itemMovie.setMovieName(objJson.getString(Constant.MOVIE_TITLE));
                            itemMovie.setMovieDescription(objJson.getString(Constant.MOVIE_DESC));
                            itemMovie.setMovieImage(objJson.getString(Constant.MOVIE_IMAGE));
                            itemMovie.setMovieLanguage(objJson.getString(Constant.MOVIE_LANGUAGE));
                            itemMovie.setMovieUrl(objJson.getString(Constant.MOVIE_URL));

                            itemMovie.setMovieType(objJson.getString(Constant.MOVIE_TYPE));
                            itemMovie.setMovieDuration(objJson.getString(Constant.MOVIE_DURATION));
                            itemMovie.setMovieDate(objJson.getString(Constant.MOVIE_DATE));
                            itemMovie.setPremium(objJson.getString(Constant.MOVIE_ACCESS).equals("Paid"));
                            itemMovie.setMovieAccess(objJson.getString(Constant.MOVIE_ACCESS));
                            if (objJson.getString(Constant.MOVIE_ACCESS).equals("Rental")) {
                                btnRental.setVisibility(View.GONE);
                                txtRentalTime.setVisibility(View.GONE);
                                txtExpire.setVisibility(View.GONE);
                                String strTime = mainJson.optString("time_remaining");
                                itemMovie.setStrTime(strTime);
//                                int minute = 0;
//                                if (strTime.contains(":")) {
//                                    String[] strHourMinute = strTime.split(":");
//                                    if (!TextUtils.isEmpty(strHourMinute[0])) {
//                                        minute = Integer.parseInt(strHourMinute[0]) * 60;
//                                        if (!TextUtils.isEmpty(strHourMinute[1]) && !strHourMinute[1].equalsIgnoreCase("00"))
//                                            minute = minute + Integer.parseInt(strHourMinute[1]);
//                                    } else {
//                                        minute = Integer.parseInt(strHourMinute[0]) * 60;
//                                    }
//                                }
//                                if (!TextUtils.isEmpty(strTime))
//                                    startTimer(minute);
//                                else {
//                                    txtExpire.setVisibility(View.GONE);
//                                    txtRentalTime.setVisibility(View.GONE);
//                                    btnRental.setVisibility(View.VISIBLE);
//                                }
                            }
                            itemMovie.setDownload(objJson.getBoolean(Constant.DOWNLOAD_ENABLE));
                            itemMovie.setDownloadUrl(objJson.getString(Constant.DOWNLOAD_URL));
                            itemMovie.setMovieRating(objJson.getString(Constant.IMDB_RATING));
                            strMovieURL = objJson.getString(Constant.MOVIE_SHARE_URL);
                            strTrailerURL = objJson.getString(Constant.TRAILER_URL);

                            if (TextUtils.isEmpty(objJson.optString(Constant.TRAILER_URL)))
                                layoutTrailer.setVisibility(View.GONE);
                            else {
                                layoutTrailer.setVisibility(View.VISIBLE);
                                layoutTrailer.setOnClickListener(v -> {
                                    if (isMovie) {
                                        ExoPlayerFragment exoPlayerFragment = ExoPlayerFragment.newInstance(objJson.optString(Constant.MOVIE_URL), false);
                                        exoPlayerFragment.setItemMovie(itemMovie);
                                        fragmentManager.beginTransaction().replace(R.id.playerSection, exoPlayerFragment).commitAllowingStateLoss();
                                        Remember.putString(Constant.MOVIE_FROM, "movie");
                                        try {
                                            textTitle.setText(objJson.getString(Constant.MOVIE_TITLE));
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                        txtMovie.setText(getString(R.string.trailer));
                                        isMovie = false;
                                    } else {
                                        ExoPlayerFragment exoPlayerFragment = ExoPlayerFragment.newInstance(objJson.optString(Constant.TRAILER_URL), true);
                                        exoPlayerFragment.setItemMovie(itemMovie);
                                        fragmentManager.beginTransaction().replace(R.id.playerSection, exoPlayerFragment).commitAllowingStateLoss();
                                        Remember.putString(Constant.MOVIE_FROM, "movie");
                                        try {
                                            textTitle.setText(objJson.getString(Constant.MOVIE_TITLE) + " Trailer");
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                        txtMovie.setText("Play Movie");
                                        isMovie = true;
                                    }
                                });
//                                int columnWidth = NetworkUtils.getScreenWidth(MovieDetailsActivity.this);
//                                imgTrailer.setLayoutParams(new RelativeLayout.LayoutParams(columnWidth / 3, columnWidth / 3 + 80));
                                Picasso.with(MovieDetailsActivity.this).load(objJson.optString(Constant.MOVIE_IMAGE)).into(imgTrailer);
                            }


                            if (mainJson.getString(Constant.IS_AVAILABLE).equalsIgnoreCase("1")) {
                                btnWatchListselect.setVisibility(View.VISIBLE);
                                btnWatchList.setVisibility(View.GONE);
                                addedWatchList = true;
                            }
                            ArrayList<ItemMovie.Videos> listVideo = new ArrayList<>();
                            if (objJson.has("videos")) {
                                JSONArray arrayVideos = objJson.getJSONArray("videos");
                                for (int i = 0; i < arrayVideos.length(); i++) {
                                    JSONObject objVideo = arrayVideos.getJSONObject(i);
                                    ItemMovie.Videos videos = new ItemMovie.Videos();
                                    videos.setLanguage(objVideo.getString("language"));
                                    videos.setUrl(objVideo.getString("url"));
                                    listVideo.add(videos);
                                }
                            }
                            itemMovie.setListVideo(listVideo);

                            ArrayList<ItemMovie.Resolution> listResolution = new ArrayList<>();
                            if (objJson.has("move_resolution")) {
                                JSONArray arrayVideos = objJson.getJSONArray("move_resolution");
                                for (int i = 0; i < arrayVideos.length(); i++) {
                                    JSONObject objVideo = arrayVideos.getJSONObject(i);
                                    ItemMovie.Resolution videos = new ItemMovie.Resolution();
                                    videos.setMovie_id(objVideo.getString("movie_id"));
                                    videos.setMovie_resolution(objVideo.getString("movie_resolution"));
                                    videos.setMovie_url(objVideo.getString("movie_url"));
                                    listResolution.add(videos);
                                }
                            }
                            itemMovie.setLstResolution(listResolution);


                            JSONArray jsonArrayChild = objJson.getJSONArray(Constant.RELATED_MOVIE_ARRAY_NAME);
                            if (jsonArrayChild.length() != 0) {
                                for (int j = 0; j < jsonArrayChild.length(); j++) {
                                    JSONObject objChild = jsonArrayChild.getJSONObject(j);
                                    ItemMovie item = new ItemMovie();
                                    item.setMovieId(objChild.getString(Constant.MOVIE_ID));
                                    item.setMovieName(objChild.getString(Constant.MOVIE_TITLE));
                                    item.setMovieImage(objChild.getString(Constant.MOVIE_POSTER));
                                    item.setMovieDuration(objChild.getString(Constant.MOVIE_DURATION));
                                    item.setPremium(objJson.getString(Constant.MOVIE_ACCESS).equalsIgnoreCase("Premium")
                                            || objJson.getString(Constant.MOVIE_ACCESS).equalsIgnoreCase("Rental")
                                            || objJson.getString(Constant.MOVIE_ACCESS).equalsIgnoreCase("Vip")
                                    );
                                    item.setMovieAccess(objJson.getString(Constant.MOVIE_ACCESS));
                                    mListItemRelated.add(item);
                                }
                            }


                            JSONArray jsonArrayGenre = objJson.getJSONArray(Constant.GENRE_LIST);
                            if (jsonArrayGenre.length() != 0) {
                                String prefix = "";
                                for (int k = 0; k < jsonArrayGenre.length(); k++) {
                                    JSONObject objChild = jsonArrayGenre.getJSONObject(k);
                                    strGenre.append(prefix);
                                    prefix = " | ";
                                    strGenre.append(objChild.getString(Constant.GENRE_NAME));
                                }
                            } else {
                                textGenre.setVisibility(View.GONE);
                            }

                        }
                        displayData();

                    } else {
                        mProgressBar.setVisibility(View.GONE);
                        lytParent.setVisibility(View.GONE);
                        lyt_not_found.setVisibility(View.VISIBLE);
                    }

                    JSONArray arrayCast = objJson.getJSONArray("movie_cast");
                    if (arrayCast.length() > 0) {
                        ArrayList<CastModel> castModelArrayList = new ArrayList<>();
                        for (int i = 0; i < arrayCast.length(); i++) {
                            JSONObject jsonData = arrayCast.optJSONObject(i);
                            castModelArrayList.add(new CastModel(jsonData.optString("image"), jsonData.optString("name"), jsonData.optString("type")));
                        }
                        recyclerCast.setAdapter(new MovieCastAdapter(MovieDetailsActivity.this, castModelArrayList, false));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                mProgressBar.setVisibility(View.GONE);
                lytParent.setVisibility(View.GONE);
                lyt_not_found.setVisibility(View.VISIBLE);
            }
        });
    }

    private void addToWatchList() {
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        params.put("movie_videos_id", Id);
        params.put("user_id", myApplication.getIsLogin() ? myApplication.getUserId() : "");
//        params.put("data", API.toBase64(jsObj.toString()));
        client.post(Constant.SAVED_TO_WATCHLIST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                mProgressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                mProgressBar.setVisibility(View.GONE);


                String result = new String(responseBody);
                try {
                    JSONObject mainJson = new JSONObject(result);
                    if (mainJson.optString("code").equalsIgnoreCase("200")) {
//                        new AlertDialog.Builder(MovieDetailsActivity.this)
//                                .setTitle(getString(R.string.app_name))
//                                .setMessage(mainJson.getString("message"))
//                                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
//                                    dialog.dismiss();
//                                })
//                                .show();

                        PrettyDialog pDialog = new PrettyDialog(MovieDetailsActivity.this);
                        pDialog
                                .setTitle(getString(R.string.app_name))
                                .setMessage(mainJson.getString("message"))
                                .setIcon(R.drawable.watchlist)
                                .addButton(
                                getString(android.R.string.ok),
                                R.color.pdlg_color_white,
                                R.color.pdlg_color_red,
                                pDialog::dismiss)
                                .show();
                        btnWatchListselect.setVisibility(View.VISIBLE);
                        btnWatchList.setVisibility(View.GONE);
                        addedWatchList = true;
                    } else {
                        mProgressBar.setVisibility(View.GONE);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                mProgressBar.setVisibility(View.GONE);
            }
        });
    }

    private void removeToWatchList() {
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        params.put("movie_videos_id", Id);
        params.put("user_id", myApplication.getIsLogin() ? myApplication.getUserId() : "");
//        params.put("data", API.toBase64(jsObj.toString()));
        client.post(Constant.REMOVE_TO_WATCHLIST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                mProgressBar.setVisibility(View.VISIBLE);

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                mProgressBar.setVisibility(View.GONE);


                String result = new String(responseBody);
                try {
                    JSONObject mainJson = new JSONObject(result);
                    if (mainJson.optString("code").equalsIgnoreCase("200")) {
//                        new AlertDialog.Builder(MovieDetailsActivity.this)
//                                .setTitle(getString(R.string.app_name))
//                                .setMessage(mainJson.getString("message"))
//                                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
//                                    dialog.dismiss();
//                                })
//                                .show();

                        PrettyDialog pDialog = new PrettyDialog(MovieDetailsActivity.this);
                        pDialog
                                .setTitle(getString(R.string.app_name))
                                .setMessage(mainJson.getString("message"))
                                .setIcon(R.drawable.watchlist)
                                .addButton(
                                        getString(android.R.string.ok),
                                        R.color.pdlg_color_white,
                                        R.color.pdlg_color_red,
                                        pDialog::dismiss)
                                .show();
                        btnWatchListselect.setVisibility(View.GONE);
                        btnWatchList.setVisibility(View.VISIBLE);
                        addedWatchList = false;
                    } else {
                        mProgressBar.setVisibility(View.GONE);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                mProgressBar.setVisibility(View.GONE);
            }
        });
    }

    private void displayData() {
        setTitle("");
        textTitle.setText(itemMovie.getMovieName());
        textDate.setText(itemMovie.getMovieDate());

        textLanguage.setText(itemMovie.getMovieLanguage());
        textGenre.setText(strGenre.toString());

        if (itemMovie.getMovieRating().isEmpty() || itemMovie.getMovieRating().equals("0")) {
            lytRate.setVisibility(View.GONE);
        } else {
            textRate.setText(itemMovie.getMovieRating());
        }

        String mimeType = "text/html";
        String encoding = "utf-8";
        String htmlText = itemMovie.getMovieDescription();

        boolean isRTL = Boolean.parseBoolean(getResources().getString(R.string.isRTL));
        String direction = isRTL ? "rtl" : "ltr";

        String text = "<html dir=" + direction + "><head>"
//                + "<style type=\"text/css\">@font-face {font-family: MyFont;src: url(\"file:///android_asset/fonts/custom.otf\")}body{font-family: MyFont;color: #9c9c9c;font-size:14px;margin-left:0px;line-height:1.3}"
                + "<style></style></head>"
                + "<body>"
                + htmlText
                + "</body></html>";


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            txtDescription.setText(Html.fromHtml(text, Html.FROM_HTML_MODE_COMPACT));
        } else {
            txtDescription.setText(Html.fromHtml(text));
        }

        new ReadMoreTextView(txtDescription, 5, "Read More", "Read less", "");
        initPlayer();
        initDownload();

        if (!mListItemRelated.isEmpty()) {
            homeMovieAdapter = new HomeMovieAdapter(MovieDetailsActivity.this, mListItemRelated, false);
            rvRelated.setAdapter(homeMovieAdapter);

            homeMovieAdapter.setOnItemClickListener(position -> {
                String movieId = mListItemRelated.get(position).getMovieId();
                Intent intent = new Intent(MovieDetailsActivity.this, MovieDetailsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("Id", movieId);
                startActivity(intent);
            });

        } else {
            lytRelated.setVisibility(View.GONE);
        }
    }

    private void initPlayer() {
        if (!itemMovie.getMovieAccess().equalsIgnoreCase("Free")) {
            if (itemMovie.getMovieAccess().equalsIgnoreCase("Rental")) {
                if (rental_plan.equalsIgnoreCase("active")) {
                    setPlayer();
                } else {
                    PremiumContentFragment premiumContentFragment = PremiumContentFragment.newInstance(Id, "Movies", itemMovie.getMovieAccess());
                    fragmentManager.beginTransaction().replace(R.id.playerSection, premiumContentFragment).commitAllowingStateLoss();
                }
            } else {
                if (isPurchased) {
                    setPlayer();
                } else {
                    PremiumContentFragment premiumContentFragment = PremiumContentFragment.newInstance(Id, "Movies", itemMovie.getMovieAccess());
                    fragmentManager.beginTransaction().replace(R.id.playerSection, premiumContentFragment).commitAllowingStateLoss();
                }
            }
        } else
            setPlayer();

    }

    private void initDownload() {
        if (itemMovie.isDownload()) {
            if (itemMovie.isPremium()) {
                if (isPurchased) {
                    btnDownload.setVisibility(View.VISIBLE);
                } else
                    btnDownload.setVisibility(View.GONE);
            } else
                btnDownload.setVisibility(View.VISIBLE);
        } else
            btnDownload.setVisibility(View.GONE);


        btnDownload.setOnClickListener(view -> {
//                if (itemMovie.getDownloadUrl().isEmpty()) {
//                    showToast(getString(R.string.download_not_found));
//                } else {
//                    try {
//                        startActivity(new Intent(
//                                Intent.ACTION_VIEW,
//                                Uri.parse(itemMovie.getDownloadUrl())));
//                    } catch (android.content.ActivityNotFoundException anfe) {
//                        Toast.makeText(MovieDetailsActivity.this, getString(R.string.invalid_download), Toast.LENGTH_SHORT).show();
//                    }
//                }

            Intent intent = new Intent(MovieDetailsActivity.this, DonateActivity.class);
            startActivity(intent);

        });
    }

    private void setPlayer() {
        if (itemMovie.getMovieUrl().isEmpty()) {
            EmbeddedImageFragment embeddedImageFragment = EmbeddedImageFragment.newInstance(itemMovie.getMovieUrl(), itemMovie.getMovieImage(), false);
            fragmentManager.beginTransaction().replace(R.id.playerSection, embeddedImageFragment).commitAllowingStateLoss();
        } else {
            switch (itemMovie.getMovieType()) {
                case "Local":
                case "URL":
                    if (getIntent().getBooleanExtra("live", false)) {
                        ExoTVPlayerFragment exoPlayerFragment = ExoTVPlayerFragment.newInstance(itemMovie.getMovieUrl(), false);
                        exoPlayerFragment.setItemMovie(itemMovie);
                        fragmentManager.beginTransaction().replace(R.id.playerSection, exoPlayerFragment).commitAllowingStateLoss();
                    } else {
                        ExoPlayerFragment exoPlayerFragment = ExoPlayerFragment.newInstance(itemMovie.getMovieUrl(), false);
                        exoPlayerFragment.setItemMovie(itemMovie);
                        fragmentManager.beginTransaction().replace(R.id.playerSection, exoPlayerFragment).commitAllowingStateLoss();
                    }
                    Remember.putString(Constant.MOVIE_FROM, "movie");
                    break;
                case "Embed":
                    EmbeddedImageFragment embeddedImageFragment = EmbeddedImageFragment.newInstance(itemMovie.getMovieUrl(), itemMovie.getMovieImage(), true);
                    fragmentManager.beginTransaction().replace(R.id.playerSection, embeddedImageFragment).commitAllowingStateLoss();
                    break;

            }
        }
    }

    public void showToast(String msg) {
        Toast.makeText(MovieDetailsActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        GlobalBus.getBus().unregister(this);
    }

    @Subscribe
    public void getFullScreen(Events.FullScreen fullScreen) {
        isFullScreen = fullScreen.isFullScreen();
        if (fullScreen.isFullScreen()) {
            gotoFullScreen();
        } else {
            gotoPortraitScreen();
        }
    }

    private void gotoPortraitScreen() {
        nestedScrollView.setVisibility(View.VISIBLE);
        toolbar.setVisibility(View.VISIBLE);
        mAdViewLayout.setVisibility(View.VISIBLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        frameLayout.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, playerHeight));
    }

    private void gotoFullScreen() {
        nestedScrollView.setVisibility(View.GONE);
        toolbar.setVisibility(View.GONE);
        mAdViewLayout.setVisibility(View.GONE);
        frameLayout.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    @Override
    public void onBackPressed() {
        if (isFullScreen) {
            Events.FullScreen fullScreen = new Events.FullScreen();
            fullScreen.setFullScreen(false);
            GlobalBus.getBus().post(fullScreen);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            FragmentManager fm = getSupportFragmentManager();
            ExoPlayerFragment fragment = (ExoPlayerFragment) fm.findFragmentById(R.id.playerSection);
//            requestWindowFeature(Window.FEATURE_NO_TITLE);
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
            assert fragment != null;
            fragment.fullScreen();

        } else {
            if (isFromNotification) {
                Intent intent = new Intent(MovieDetailsActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            } else {
                super.onBackPressed();
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        if (v == btnWatchList) {
            if (NetworkUtils.isConnected(MovieDetailsActivity.this)) {
                if (myApplication.getIsLogin())
                    addToWatchList();
                else
                    showToast(getString(R.string.valid_login_first));
            } else {
                showToast(getString(R.string.conne_msg1));
            }
        } else if (v == btnWatchListselect) {
            if (NetworkUtils.isConnected(MovieDetailsActivity.this)) {
                if (myApplication.getIsLogin())
                    removeToWatchList();
                else
                    showToast(getString(R.string.valid_login_first));
            } else {
                showToast(getString(R.string.conne_msg1));
            }
        } else if (v == btnShare) {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
            String shareMessage = "\n" + strMovieURL + "\n\n";
//            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        } else if (v == btnRental) {
            startActivity(new Intent(MovieDetailsActivity.this, PlanActivity.class).putExtra("rental", "true"));
        } else if (v == btnDownloadMovie) {
            DialogUtil.AlertBox(MovieDetailsActivity.this, getString(R.string.app_name), "This Feature will be available in live application");
        } else if (v == txtDownload) {
            DialogUtil.AlertBox(MovieDetailsActivity.this, getString(R.string.app_name), "This Feature will be available in live application");
        } else if (v == txtShare) {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
            String shareMessage = "\n" + strMovieURL + "\n\n";
//            shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
            startActivity(Intent.createChooser(shareIntent, "choose one"));
        }
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        super.onCreateOptionsMenu(menu);
//        getMenuInflater().inflate(R.menu.browse, menu);
//        mediaRouteMenuItem = CastButtonFactory.setUpMediaRouteButton(getApplicationContext(), menu,
//                R.id.media_route_menu_item);
//        return true;
//    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (NetworkUtils.isConnected(MovieDetailsActivity.this)) {
                getDetails();
            } else {
                showToast(getString(R.string.conne_msg1));
            }
        }
    }

    public void hideShowBackButton(boolean hideShow) {
        if (hideShow)
            imgBack.setVisibility(View.VISIBLE);
        else
            imgBack.setVisibility(View.GONE);
    }


    @Override
    public void onPositiveClick(int from) {
        if (from == 101) {
            startActivity(new Intent(MovieDetailsActivity.this, SignInActivity.class));
        }
    }

    @Override
    public void onNegativeClick(int from) {

    }

    @Override
    public void onNeutralClick(int from) {

    }


    private void startTimer(int noOfMinutes) {
        countDownTimer = new CountDownTimer(noOfMinutes * 60 * 1000, 1000) {
            public void onTick(long millisUntilFinished) {
                //Convert milliseconds into hour,minute and seconds
                @SuppressLint("DefaultLocale") String hms = String.format("%02dh:%02dm", TimeUnit.MILLISECONDS.toHours(millisUntilFinished), TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millisUntilFinished)), TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)));
                txtRentalTime.setText(hms);//set text
            }

            public void onFinish() {

                txtRentalTime.setText("TIME'S UP!!"); //On finish change timer text
                countDownTimer = null;//set CountDownTimer to null
                finish();
            }
        }.start();

    }
}
