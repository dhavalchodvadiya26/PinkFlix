package com.example.videostreamingapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.util.API;
import com.example.util.Constant;
import com.example.util.DeviceUtils;
import com.example.util.DialogUtil;
import com.example.util.IsRTL;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Password;
import com.ybs.countrypicker.CountryPicker;
import com.ybs.countrypicker.CountryPickerListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Objects;

import cn.refactor.library.SmoothCheckBox;
import cz.msebera.android.httpclient.Header;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;


public class SignInActivity extends AppCompatActivity implements View.OnClickListener {
    @NotEmpty
    @Email
    EditText edtEmail;
    @NotEmpty
    @Password
    EditText edtPassword;
    String strEmail, strPassword, strMessage, strName, strUserId;
    Button btnLogin;
    TextView btnForgotPass, btnRegister;
    MyApplication myApplication;
    ProgressDialog pDialog;
    SmoothCheckBox checkBox;
    boolean isFromOtherScreen = false;
    String postId, postType;
    ImageView btnFacebook, btnGoogle;
    private EditText edtCountry;
    private CallbackManager callbackManager;
    private ImageView imgShowPassword;
    private boolean showPassword;
    private GoogleSignInOptions gso;
    private static final int RC_SIGN_IN = 9001;

    private GoogleSignInClient mGoogleSignInClient;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        IsRTL.ifSupported(this);

        Intent intent = getIntent();
        if (intent.hasExtra("isOtherScreen")) {
            isFromOtherScreen = true;
            postId = intent.getStringExtra("postId");
            postType = intent.getStringExtra("postType");
        }

        pDialog = new ProgressDialog(this);
        myApplication = MyApplication.getInstance();
        edtCountry = findViewById(R.id.edtCountry);
        edtCountry.setFocusable(false);
        edtCountry.setClickable(true);
        edtCountry.setOnClickListener(this);
        edtEmail = findViewById(R.id.editText_email_login_activity);
        edtPassword = findViewById(R.id.editText_password_login_activity);
        btnLogin = findViewById(R.id.button_login_activity);

        btnForgotPass = findViewById(R.id.textView_forget_password_login);
        btnRegister = findViewById(R.id.textView_signup_login);
        checkBox = findViewById(R.id.checkbox_login_activity);
        btnFacebook = findViewById(R.id.button_fb_login);
        btnGoogle = findViewById(R.id.button_google_login);
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        btnGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });
        btnFacebook.setOnClickListener(v -> doFacebookLogin());
        btnRegister.setOnClickListener(v -> {
            Intent intent1 = new Intent(SignInActivity.this, SignUpActivity.class);
            intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent1);
        });

        /*btnSkip.setOnClickListener(v -> {
            Intent intent12 = new Intent(SignInActivity.this, MainActivity.class);
            intent12.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent12);
            finish();
        });*/

        btnForgotPass.setOnClickListener(v -> {
            Intent intent13 = new Intent(SignInActivity.this, ForgotPasswordActivity.class);
            intent13.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent13);
        });

        btnLogin.setOnClickListener(v ->
        {
            if (!TextUtils.isEmpty(edtEmail.getText().toString().trim()))
                if (!TextUtils.isEmpty(edtPassword.getText().toString().trim()))
                    putSignIn();
                else
                    DialogUtil.AlertBox(SignInActivity.this, getString(R.string.app_name), "Please Enter Password");
            else
                DialogUtil.AlertBox(SignInActivity.this, getString(R.string.app_name), "Please Enter Mobile No");

        });
        imgShowPassword = findViewById(R.id.imgShowPassword);
        imgShowPassword.setOnClickListener(v -> {
            if (showPassword) {
                imgShowPassword.setImageResource(R.drawable.ic_hide);
                edtPassword.setTransformationMethod(new PasswordTransformationMethod());
                showPassword = false;
            } else {
                imgShowPassword.setImageResource(R.drawable.ic_eye);
                edtPassword.setTransformationMethod(null);
                edtPassword.setSelection(edtPassword.getText().toString().length());
                showPassword = true;
            }
        });
        if (myApplication.getIsRemember()) {
            checkBox.setChecked(true);
            edtEmail.setText(myApplication.getRememberEmail());
            edtPassword.setText(myApplication.getRememberPassword());
            imgShowPassword.setVisibility(View.GONE);
        }


        myApplication.saveIsIntroduction(true);
    }


    public void doFacebookLogin() {
        callbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().logInWithReadPermissions(SignInActivity.this, Arrays.asList("email", "public_profile"));
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                AccessToken accessToken = loginResult.getAccessToken();
                GraphRequest graphRequest = GraphRequest.newMeRequest(accessToken, (object, response) -> parseFacebookResponse(response));
                Bundle bundle = new Bundle();
                bundle.putString("fields", "id,name,email,picture.type(large)");
                graphRequest.setParameters(bundle);
                graphRequest.executeAsync();
            }

            @Override
            public void onCancel() {
                Toast.makeText(SignInActivity.this, "Something problem in facebook login. try again", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(FacebookException error) {
                Toast.makeText(SignInActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void parseFacebookResponse(GraphResponse response) {
        try {
            JSONObject jsonObject = response.getJSONObject();
            String strID = jsonObject.optString(Constant.FB_ID);
            String strName = jsonObject.optString(Constant.FB_NAME);
            String strEmail = jsonObject.optString(Constant.FB_EMAIL);
            String strPicture = Objects.requireNonNull(Objects.requireNonNull(jsonObject.optJSONObject(Constant.FB_PICTURE)).optJSONObject(Constant.FB_DATA)).optString(Constant.FB_PICTURE_URL);
            String strPhotoUrl = "";
            strPhotoUrl = strPicture;
            if (strName.equalsIgnoreCase("")) {
                Toast.makeText(this, "We could not get name from your facebook account.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (strEmail.equalsIgnoreCase("")) {
                Toast.makeText(this, "We could not get email from your facebook account.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Welcome!, You have successfully login with facebook", Toast.LENGTH_SHORT).show();
            callFacebookApi(strName, strEmail);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void callFacebookApi(String strName, String strEmail) {
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();

        JsonObject objData = (JsonObject) new Gson().toJsonTree(new API());
        params.put("email", strEmail);
        params.put("name", strName);
        params.put("is_facebook", "123456");
//        params.put("android_version", Build.VERSION.SDK);
//        params.put("device_id", DeviceUtils.getDeviceUid());
//        params.put("version_name", BuildConfig.VERSION_NAME);
//        params.put("device", Build.DEVICE + ":" + Build.BRAND + ":" + Build.MODEL + ":" + Build.MANUFACTURER);
        params.put("data", API.toBase64(objData.toString()));

        Log.d("DETAILS", params.toString());

        client.post(Constant.LOGIN_WITH_FACEBOOK_URL, params, new AsyncHttpResponseHandler() {

            @Override
            public void onStart() {
                super.onStart();
                showProgressDialog();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                dismissProgressDialog();
                String result = new String(responseBody);
                Log.d("RESPONSE", result);
                try {
                    JSONObject mainJson = new JSONObject(result);
                    JSONArray jsonArray = mainJson.getJSONArray(Constant.ARRAY_NAME);
                    JSONObject objJson;
                    for (int i = 0; i < jsonArray.length(); i++) {
                        objJson = jsonArray.getJSONObject(i);
                        Constant.GET_SUCCESS_MSG = objJson.getInt(Constant.SUCCESS);
                        if (Constant.GET_SUCCESS_MSG == 0) {
                            strMessage = objJson.getString(Constant.MSG);
                        } else {
                            try {
                                JSONArray arrUserList = objJson.getJSONArray("user_list");
                                if (arrUserList != null &&
                                        arrUserList.length() > 0) {
                                    JSONObject objUser = arrUserList.getJSONObject(i);
                                    SignInActivity.this.strName = objUser.getString(Constant.USER_NAME);
                                    strUserId = objUser.getString(Constant.FB_ID);
                                }
                            } catch (Exception e) {
                                strMessage = "Error while login with facebook";
                            }
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                setResult();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                dismissProgressDialog();
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (callbackManager != null) {
            callbackManager.onActivityResult(requestCode, resultCode, data);
        } else if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            // Signed in successfully, show authenticated UI.
            updateUI(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w("TAG", "signInResult:failed code=" + e.getStatusCode());
            updateUI(null);
        }
    }

    private void updateUI(@Nullable GoogleSignInAccount account) {
        if (account != null)
            Toast.makeText(myApplication, "" + account.getDisplayName(), Toast.LENGTH_SHORT).show();
    }



   /* @Override
    public void onValidationSucceeded() {
        if (NetworkUtils.isConnected(SignInActivity.this)) {
            putSignIn();
        } else {
            showToast(getString(R.string.conne_msg1));
        }
    }*/

    public void putSignIn() {
        strEmail = edtEmail.getText().toString();
        strPassword = edtPassword.getText().toString();

        if (checkBox.isChecked()) {
            myApplication.saveIsRemember(true);
            myApplication.saveRemember(strEmail, strPassword);
        } else {
            myApplication.saveIsRemember(false);
        }

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();

        JsonObject jsObj = (JsonObject) new Gson().toJsonTree(new API());
        jsObj.addProperty("email", strEmail);
        jsObj.addProperty("password", strPassword);
//        jsObj.addProperty("android_version", Build.VERSION.SDK);
//        jsObj.addProperty("device_id", DeviceUtils.getDeviceUid());
//        jsObj.addProperty("version_name", BuildConfig.VERSION_NAME);
//        jsObj.addProperty("device", Build.DEVICE + ":" + Build.BRAND + ":" + Build.MODEL + ":" + Build.MANUFACTURER);
        params.put("data", API.toBase64(jsObj.toString()));

        client.post(Constant.LOGIN_URL, params, new AsyncHttpResponseHandler() {

            @Override
            public void onStart() {
                super.onStart();
                showProgressDialog();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                dismissProgressDialog();
                String result = new String(responseBody);
                try {
                    JSONObject mainJson = new JSONObject(result);
                    JSONArray jsonArray = mainJson.getJSONArray(Constant.ARRAY_NAME);
                    JSONObject objJson;
                    for (int i = 0; i < jsonArray.length(); i++) {
                        objJson = jsonArray.getJSONObject(i);
                        Constant.GET_SUCCESS_MSG = objJson.getInt(Constant.SUCCESS);
                        if (Constant.GET_SUCCESS_MSG == 0) {
                            strMessage = objJson.getString(Constant.MSG);
                        } else {
                            strName = objJson.getString(Constant.USER_NAME);
                            strUserId = objJson.getString(Constant.USER_ID);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                setResult();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                dismissProgressDialog();
            }

        });
    }


    /*@Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(this);
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        }
    }*/

    public void setResult() {

        if (Constant.GET_SUCCESS_MSG == 0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(SignInActivity.this);
            builder.setMessage(strMessage)
                    .setCancelable(false)
                    .setPositiveButton("OK", (dialog, id) -> {
                        dialog.dismiss();
                    });
            AlertDialog alert = builder.create();
            alert.show();
        } else {
            myApplication.saveIsLogin(true);
            myApplication.saveLogin(strUserId, strName, strEmail);
            if (isFromOtherScreen) {
                Class<?> aClass;
                switch (postType) {
                    case "Movies":
                        aClass = MovieDetailsActivity.class;
                        break;
                    case "Shows":
                        aClass = ShowDetailsActivity.class;
                        break;
                    case "LiveTV":
                        aClass = TVDetailsActivity.class;
                        break;
                    default:
                        aClass = SportDetailsActivity.class;
                        break;
                }
                Intent intent = new Intent(SignInActivity.this, aClass);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("Id", postId);
                startActivity(intent);
            } else {
                Intent i = new Intent(SignInActivity.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        }
    }

    public void showToast(String msg) {
        Toast.makeText(SignInActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    public void showProgressDialog() {
        pDialog.setMessage(getString(R.string.loading));
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();
    }

    public void dismissProgressDialog() {
        if (pDialog != null && pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public void onClick(View v) {
        if (v == edtCountry) {
            CountryPicker picker = CountryPicker.newInstance("Select Country");
            picker.setListener((name, code, dialCode, i) -> {
                edtCountry.setText(dialCode);
                if (dialCode.equalsIgnoreCase("+91"))
                    edtEmail.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
                else
                    edtEmail.setFilters(new InputFilter[]{new InputFilter.LengthFilter(14)});

                picker.dismiss();
            });
            picker.show(getSupportFragmentManager(), "COUNTRY_PICKER");
        }
    }
}
