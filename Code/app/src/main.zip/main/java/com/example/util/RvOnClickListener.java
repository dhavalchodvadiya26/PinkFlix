package com.example.util;

import android.view.View;

public interface RvOnClickListener {
    void onItemClick(int position);
}
